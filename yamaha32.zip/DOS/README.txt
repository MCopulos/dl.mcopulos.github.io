**********************************
    How to use DOS directory
**********************************
							YAMAHA CORP.


This is for pure DOS environment setup. If your system supports Windows3.1
or Windows95, please go to Setup directory. 

1. How to install
From DOS prompt, type "install" and put return key, then setup sequence will
be initialized. If you need to connect IDE CDROM from Sound Card, please type
"instdos -c", optional command.

2. Supported languages
It supports 6 languages. 
English/French/German/Italian/Japanese/Spanish 