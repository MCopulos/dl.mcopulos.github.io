EasyWrite for Windows 1.0
-------------------------
This is an easy, distraction free writing program for Windows and OS/2 PCs*. It's also designed to run on everything that is IBM PC AT compatible or better.

INSTALLATION
-------------------------
To install EasyWrite for Windows 1.0, your computer must meet the requirements:

MINIMUM:
286 or compatible
2 MB of RAM
Hercules, EGA, VGA or better display
550 KB of free disk space
Microsoft Windows 3.0 or later

RECOMMENDED:
386DX or better
4 MB of RAM
800x600 true color SVGA display
2 MB of free disk space
Microsoft Windows 3.0 Multimedia Edition or Windows 3.1

If your computer meets these, open your run dialog of choice, and enter A:\setup.bat. From there, follow the instructions and your program will be installed. If that doesn't work, you can install from A:\ALT\SETUP.EXE. That method requires Windows 3.1 or later.

TIPS:
If you experience issues installing the program on Windows NT 6 or later, run the setup script as an administrator.

For optimal usage, try using a 1024x768 display or higher with a 24 point font size.

*OS/2 has not been tested so far, but will probably work.

Source code is available in the SRC directory/ Using it requires a copy of Microsoft Visual Basic 3.0 or better.

For support, please visit http://www.mcopulos.com

LICENSE (also available in LICENSE.TXT and the License program item)
--------------------------------------------------------------------
Copyright (c) 2026, MCopulos.com Software All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
3. All advertising materials mentioning features or use of this software must display the following acknowledgement: This product includes software developed by MCopulos.com Software.
4. Neither the name of the MCopulos.com Software nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY MCOPULOS.COM SOFTWARE AS IS AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL MCOPULOS.COM SOFTWARE BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
